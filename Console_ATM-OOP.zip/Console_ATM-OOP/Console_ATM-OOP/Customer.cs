﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace Console_ATM_OOP
{
    class Customer
    {
        public string Name { get; set; }
        public string Passcode { get; set; }
        public int Balance { get; set; }
    }
}